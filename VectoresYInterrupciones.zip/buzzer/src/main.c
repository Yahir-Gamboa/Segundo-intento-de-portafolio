#include <avr/io.h>
#include <util/delay.h>

int main (void){
 
 //int buzzerpin = PB1;  

    TCCR1B=(1<<CS10)|(1<<WGM12)|(1<<WGM13);
    TCCR1A=(1<<WGM11)|(1<<COM1B1);
    
    // Configurar PB1 (OC1A) como salida
    //DDRB |= (1 << buzzerpin);
    DDRB=1<<PB2;
    
    /*
    while(1){
        //mi
        ICR1 = 955.11;
        OCR1B = ICR1 / 4;
        _delay_ms(500);
        //sol
        ICR1 = 851.06;
        OCR1B = ICR1 / 4;
        _delay_ms(500);
        //si
        ICR1 = 758.15;
        OCR1B = ICR1 / 4;
        _delay_ms(500);
        //do
        ICR1 = 715.82;
        OCR1B = ICR1 / 4;
        _delay_ms(500);
        //do
        ICR1 = 637.76;
        OCR1B = ICR1 / 4;
        _delay_ms(500);
        //si
        ICR1 = 568.18;
        OCR1B = ICR1 / 4;
        _delay_ms(500);
        //sol
        ICR1 = 506.07;
        OCR1B = ICR1 / 4;
        _delay_ms(500);
 
        _delay_ms(1000);  // pausa de 1 segundo entre cada una
      */
        //stranger things 
        while(1){
        
        //mi
        ICR1 = 758.15;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
        //sol
        ICR1 = 637.76;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
        //si
        ICR1 = 506.07;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
        //do
        ICR1 = 955.11;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
        //do
        ICR1 = 955.11;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
        //si
        ICR1 =506.07;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
       //sol
        ICR1 = 637.76;
        OCR1B = ICR1 / 4;
        _delay_ms(260);

       //mi
        ICR1 = 758.15;
        OCR1B = ICR1 / 4;
        _delay_ms(260);

        //sol
        ICR1 = 637.76;
        OCR1B = ICR1 / 4;
        _delay_ms(260);

       //si
        ICR1 =506.07;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
        //do
        ICR1 =955.11 ;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
     //do
        ICR1 = 955.11;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
        //si
        ICR1 =506.07;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
       //sol
        ICR1 = 637.76;
        OCR1B = ICR1 / 4;
        _delay_ms(260);

       //mi
        ICR1 = 758.15;
        OCR1B = ICR1 / 4;
        _delay_ms(260);

        //sol
        ICR1 = 637.76;
        OCR1B = ICR1 / 4;
        _delay_ms(260);

       //si
        ICR1 =506.07;
        OCR1B = ICR1 / 4;
        _delay_ms(260);
        
        //do
        ICR1 =955.11 ;
        OCR1B = ICR1 / 4;
        _delay_ms(280);
 
        _delay_ms(1000);  // pausa de 1 segundo entre cada una
    }   
    return 0;
}