#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>



volatile int i = 0;
volatile int brillito = 0;
//int display[6];
int display[6]={0b00111111, 0b00000110, 0b01011011, 0b01001111, 0b1100110, 0b01101101 };

void int_init()
{
        EICRA=0b1111; 
        EIMSK=0b11; // se quita la madre de int 1 alv
}

ISR(INT1_vect) //hacer como si fuera led, que prenda uno (se quita la madre de abajo)
{ 
        //int display[6];
        if(i == 4){
           
        brillito = 1;
        /*
          for(int j = 0; j < 3; j++)
          {
            PORTB = 0b1100110; // apagar display
            _delay_ms(250);
            PORTB = display[i]; // mostrar número 4
            _delay_ms(250);
          }
          //i =5;
        
           PORTB = 0b1100110;
           _delay_ms(250);
           PORTB = 0b1100110;
           _delay_ms(250);
           PORTB = 0b1100110;
           _delay_ms(250);
           PORTB = display[i];
           _delay_ms(250);
             
                
                PORTB=0xff;
                _delay_ms(2000); 
                */   
        }
}
int main(void)
{
    sei();
    int_init();
    DDRB=0xFF;
    DDRD=0;
    //int display[6]={0b00111111, 0b00000110, 0b01011011, 0b01001111, 0b1100110, 0b01101101 };
    //DDRC=0xFF;
    //DDRD=0x00;

    while(1)
    {
        if(i==4  && brillito){
                for (int j=0;j<3;j++){
                 PORTB = 0b1100110; // apagar display
                _delay_ms(250);
                PORTB = display[i]; // mostrar número 4
                _delay_ms(250);
        }
                brillito = 0;
        } else {
        PORTB = display[i];
        _delay_ms(1000);
        i++;
        if(i == 6) 
        {
              i=0;  
        }       
        /*
        if (brillito){
        for(int j = 0; j < 3; j++){
        PORTB = 0b1100110;
        _delay_ms(250);
        PORTB = display[i];
        _delay_ms(250);
        }
        
        i = 5;
        brillito = 0;
        */
        }

    }

}




 
