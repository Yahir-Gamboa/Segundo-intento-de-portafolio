#include <avr/io.h>
#include <util/delay.h>
int x = 0;
int y = 0;
int i= 0;
int main(void){
    //      76543210
    DDRB = 0b00001111;//DDRB el puerto B se configura como un output
    while(1)
   { 
    for (x=0; x<=3; x++)
    {
        for (y=0;y<=3-x;y++)
        {
            PORTB=1<<y|i;
            _delay_ms(1000);
        }
        i=PORTB;
    }
    i=0;
    PORTB=0;
    }
    return 0;
}