#include <avr/io.h>
#include <avr/interrupt.h>


/* codigo del nombre 
int main()
{
    DDRD = 0b00000000;//entradas de PD0, PD1  
    DDRB = 0b001111;//prender PB0, PB1, PB2, PB3
    PORTB=0b1;
    int flag=0,flag2=0, avz=0; 
     while(1)
    {
        if ((PINB & (1<<PINB0) && flag == 0) ) 
        {
            
            PORTB= 1<<avz;
            avz++;
            if(avz>3){
                avz=0;
            }
            flag = 1 ;
        }
        else if (!(PINB & (1<<PINB0)))
        {
            flag = 0;
        }
            if ((PINB & (1<<PINB1) && flag2 == 0) ) 
        {
            
            PORTB = 1<<avz;
            avz--;
            if(avz<0){
                avz=3;
            }
            flag2 = 1 ;
        }
        else if (!(PINB & (1<<PINB1)))
      {
            flag2 = 0;
      }
    }
}

*/

int velocidad = 128;  // Velocidad inicial (0-255)
int direccion = 1;  // 1 adelante, -1 atrás
volatile uint8_t boton_estado = 0;


void init_pwm() {
    // Configurar Timer0 para PWM rápido en PD5 (OC0B)
    TCCR0A |= (1 << COM0B1) | (1 << WGM00) | (1 << WGM01);
    TCCR0B |= (1 << CS01);  // Prescaler 8
    DDRD |= (1 << DDD5);    // Configurar PD5 (OC0B) como salida
}

void set_motor(int dire, int velo) {
    if (dire > 0) {
        // Adelante
        PORTB = 0b01;
    } else {
        // Atrás
        PORTB = 0b10;
    }
    OCR0B = velo;  // Establecer el ciclo de trabajo PWM en OC0B (PD5)
}

ISR(PCINT2_vect) {
    boton_estado = PIND & 0b00000111;  // Capturar estado de PD0, PD1, PD2
}

void check_buttons() {
    cli();  // Deshabilitar interrupciones brevemente
    uint8_t estado = boton_estado;
    boton_estado = 0;
    sei();  // Rehabilitar interrupciones

    // Botón 1: Aumentar velocidad
    if (!(estado & (1 << PIND0)) && velocidad < 245) {
        velocidad += 10;
    }
    
    // Botón 2: Disminuir velocidad
    if (!(estado & (1 << PIND1)) && velocidad > 10) {
        velocidad -= 10;
    }
    
    // Botón 3: Cambiar dirección
    if (!(estado & (1 << PIND2))) {
        direccion *= -1;
    }
    
    set_motor(direccion, velocidad);
}

int main() {
    // Configurar PD0, PD1, PD2 como entradas (botones)
    DDRD &= ~((1 << DDD0) | (1 << DDD1) | (1 << DDD2));
    // Habilitar pull-ups internos para los botones
    PORTD |= (1 << PORTD0) | (1 << PORTD1) | (1 << PORTD2);
    
    // Configurar PB0 y PB1 como salidas para control de dirección
    DDRB |= (1 << DDB0) | (1 << DDB1);
    
    // Habilitar interrupciones de cambio de pin para PORTD
    PCICR |= (1 << PCIE2);
    PCMSK2 |= (1 << PCINT16) | (1 << PCINT17) | (1 << PCINT18);
    
    init_pwm();
    set_motor(direccion, velocidad);
    
    sei();  // Habilitar interrupciones globales
    
    while(1) {
        check_buttons();
    }
    
    return 0;
}