#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/*
void pwm_init(){
  // initialize TCCR0 as per requirement, say as follows
 TCCR0A = (1<<WGM00)|(1<<COM0A1)|(1<<WGM01);
 // make sure to make OC0 pin (pin PB3 for atmega32) as output pin
 TCCR0B=(1<<CS01);
 DDRD |= (1<<PD6);
 }
  
 int main (void)
 {
 uint8_t bajo = 0;
 int8_t alto = 1;
 // duty cycle = 45% of 255 = 114.75 = 115
 // initialize timer in PWM mode
 pwm_init();
 // run forever
 while(1)
 {
  OCR0A = bajo;
 if (alto == 1) {
            if (bajo < 255) bajo++;
        } else {
            if (bajo > 0) bajo--;
        }

        // Cambiar dirección en los extremos
        if (bajo == 255 || bajo == 0) {
            alto = -alto;
            _delay_ms(200);  // Pausa en los extremos
        }

        _delay_ms(5);  // Controla la velocidad del efecto
    }

    return 0;
}
*/
void pwm_init() {
    // Configurar el temporizador en modo Fast PWM, no inverso, con preescalador sin división (CS00)
    TCCR0A = (1 << WGM00) | (1 << COM0A1) | (1 << WGM01);
    TCCR0B |= (1 << CS01);//DEPENDE DE QUE ESTE CONTANTDO TIEMPO. PRENDE EL TEMPORIZADOR,

    // Configurar el pin OC0A (PB0 en ATmega328P) como salida
    DDRD |= (1 << PD6);
}

int main() {
    uint8_t duty = 2;
    // Ciclo de trabajo = 45% de 255 = 114.75 ≈ 115

    // Inicializar el temporizador en modo PWM
    pwm_init();

    // Bucle infinito
    while (1) {
        OCR0A = duty;
        for(duty = 0; duty<255;duty++)
        {

             OCR0A = duty;
            _delay_ms(1);
        }
        for(duty = 255; duty>0 ;duty--)
        {
            
             OCR0A = duty;
            _delay_ms(5);
        }
     

}
}