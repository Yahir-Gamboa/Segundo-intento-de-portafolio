#include <avr/io.h>
#include <avr/interrupt.h>
volatile uint16_t timerOverflowCount=0;
volatile uint16_t led1 = 0;
volatile uint16_t led2 = 0;
/*
  FCPU 1MHZ
  Ftimer = 1mhz/8 = 125KHz
  1 pulso = 8us
  1 ovF=255 pulsos = 255*8 = 2ms

*/
void timer0_init(){
    TCCR0B|=(1<<CS01);//PS = 8
    TCNT0 = 0;
    TIMSK0|=(1<<TOIE0);
    sei();
}
ISR(TIMER0_OVF_vect){
timerOverflowCount++;
led1++;
led2++;
}
int main(){
  DDRB |= (1 << PB0) | (1 << PB1); 
  timer0_init();
  while(1){
    if (led1>=1500){  
      PORTB^= (1 << 0) ;
      led1=0;
    }
    if (led2>=750){  
      PORTB^= (1 << 1) ;
      led2=0;
    }
  }
}