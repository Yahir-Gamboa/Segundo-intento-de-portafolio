#include <avr/io.h>

int main (void)
{

//El puerto B se declara como entrada 
DDRB = 0x00;
//El puerto B se decalara como salida
DDRB = 0xFF;
//PORTB = 0;
while(1)
{
  //Condicion para revisar si el Pin0 existe un 1 logico
  
  /*if(PINB & (1<<PINB0))
{

    PORTB = 0xFF;// SE PRENDEN LA LINEA DE ENERGIA
}
//Condicion para revisar si en el Pin0 existe un 0 logico 
else if (!(PINB & (1<<PINB0)))
   {
     PORTB = 0x00;

   }
}
}
*/
//AND

if (!(PINB &(1<<2)))

if (PINB &(1<<0)&&PINB &(1<<1))
 {
PORTB=0XFF;
 }
else
{
PORTB=0;
}
}
}
/*



//OR
if(!(PINB & (1<<2)))

if(!(PINB & (1<<0)) && !(PINB & (1<<1)))
{
PORTB=0;
}
else
{
PORTB=0xff;
}

    
//OR
        // Verifica el estado de los botones
        if (!(PINB & (1 << PINB0)) && !(PINB & (1 << PINB1))) {
            // Si ambos botones están presionados, enciende el LED
            PORTD = 0xFF;  // Enciende todos los LEDs en PORTD
        } else {
            // Si al menos uno de los botones no está presionado, apaga el LED
            PORTD = 0x00;  // Apaga todos los LEDs en PORTD
        }
    }

    return 0;  // Esta línea nunca se ejecutará
*/
